
/**
 * Write a description of class ola here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class ola
{
    // instance variables - replace the example below with your own
    private int x;
    private int ola;
    private adeus adeus1;
    /**
     * Constructor for objects of class ola
     */
    public ola()
    {
        // initialise instance variables
        x = 0;
        this.ola = 10;
    }
        
   
}
